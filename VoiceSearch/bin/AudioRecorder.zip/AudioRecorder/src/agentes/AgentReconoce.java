package agentes;

import metodos.IdentifyProtocolV1;
import metodos.Song;
import metodos.Utils;
import agentes.launcher.*;
import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import java.io.IOException;
import java.io.Serializable;


public class AgentReconoce extends AgentBase {


	private static final long serialVersionUID = 1L;
	public static final String NICKNAME = "Reconoce";

	protected void setup()
	{
		super.setup();
		this.type=AgentModel.RECONOCE;
		registerAgentDF();
		addBehaviour(new Reconoce());
	}	


	private class Reconoce extends OneShotBehaviour{
		@Override
		public void action() {

			ACLMessage msg
					=this.myAgent.blockingReceive(MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.REQUEST), MessageTemplate.MatchOntology("ontologia")));
			
			System.out.println("Agente agenteReconoce");
			System.out.println("Mensaje: "+(String)msg.getContent());
			
			String recog = IdentifyProtocolV1.main(msg.getContent());
			
			
			
			//enviar
			Utils.enviarMensaje(this.myAgent, "Analisis", recog);
			System.out.println("Mensaje Enviado a Analisis"); 
		}
	}


}



