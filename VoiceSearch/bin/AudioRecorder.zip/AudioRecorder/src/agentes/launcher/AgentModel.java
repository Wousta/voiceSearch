package agentes.launcher;

public enum AgentModel {

	RECORDER("Recorder"),
	RECONOCE("Reconoce"),
	ANALISIS("Analisis"),
	INTERFAZ("Interfaz"),
	DESCONOCIDO("Desconocido");

    private final String value;

    AgentModel(String value){ 
    	this.value = value; 
    	}

    public String getValue(){ 
    	return this.value; 
    }

    public static AgentModel getEnum(String value) {
        switch (value) {
            case "Recorder":
                return RECORDER;
            case "Reconoce":
                return RECONOCE;
            case "Analisis":
                return ANALISIS;
            case "Interfaz":
                return INTERFAZ;
            default:
                return DESCONOCIDO;
        }
    }
	
}