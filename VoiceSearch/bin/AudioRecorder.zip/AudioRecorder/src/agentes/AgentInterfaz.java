package agentes;

import agentes.launcher.*;
import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import java.io.IOException;
import java.io.Serializable;

public class AgentInterfaz extends AgentBase{

	private static final long serialVersionUID = 1L;
	public static final String NICKNAME = "Interfaz";

	protected void setup()
	{
		super.setup();
		this.type=AgentModel.INTERFAZ;
		addBehaviour(new Interfaz());
		registerAgentDF();
	}

	private class Interfaz extends CyclicBehaviour{
		

		@Override
		public void action() {
			ACLMessage msg =
					blockingReceive(MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.REQUEST), MessageTemplate.MatchOntology("ontologia")));
			
			System.out.println("Agente agenteInterfaz");
			System.out.println("Mensaje: " + msg.getContent());
			
			

		}

	}


}
