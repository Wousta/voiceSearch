package agentes;

import agentes.launcher.*;
import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import metodos.Utils;

import java.io.IOException;
import java.io.Serializable;

import org.json.*;

public class AgentAnalisis extends AgentBase {

	private static final long serialVersionUID = 1L;
	public static final String NICKNAME = "Analisis";

	protected void setup()
	{
		super.setup();
		this.type=AgentModel.ANALISIS;
		addBehaviour(new Analisis());
		registerAgentDF();
	}

	private class Analisis extends CyclicBehaviour{

		@Override
		public void action() {
			ACLMessage msg
					=this.myAgent.blockingReceive(MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.REQUEST), MessageTemplate.MatchOntology("ontologia")));
			
			System.out.println("Agente agenteAnalisis");
			System.out.println("Mensaje: "+(String)msg.getContent());
			
			JSONObject json = new JSONObject(msg.getContent());
			
			JSONObject metadata = json.getJSONObject("metadata");
			JSONArray music = metadata.getJSONArray("music");
			JSONObject all_music = music.getJSONObject(0);
			JSONObject external = all_music.getJSONObject("external_metadata");
			JSONObject spotify = external.getJSONObject("spotify");
			
			JSONArray artists = spotify.getJSONArray("artists");
			String[] artistas = new String[artists.length()];
			for(int i = 0; i<artists.length();i++) {
				JSONObject artista = artists.getJSONObject(i);
				Object nameO = artista.get("name");
				String name = nameO.toString();
				artistas[i]=name;

				
			}			
			JSONObject track = spotify.getJSONObject("track");
			Object nameO = track.get("name");
			Object idO = track.get("id");
			String id = idO.toString();
			String name = nameO.toString();
			String artista = artistas[0];
			for(int i = 1; i<artistas.length;i++) {
				artista = artista + ", " + artistas[i];
			}
			
				
			String res="id: "+id + " name: " + name + " artists: " + artista;      
			
	        Utils.enviarMensaje(this.myAgent, "Interfaz", res);
			System.out.println("Mensaje Enviado a Interfaz");
			

		}

	}

}
