package agentes;

import agentes.launcher.AgentModel;
import jade.core.*;
import jade.core.behaviours.*;
import jade.lang.acl.*;
import metodos.*;
import agentes.launcher.*;


public class AgentRecorder extends AgentBase {


	private static final long serialVersionUID = 1L;
	public static final String NICKNAME = "Recorder";

	protected void setup()
	{
		super.setup();
		this.type=AgentModel.RECORDER;
		registerAgentDF();
		addBehaviour(new Recorder());
	}	


	private class Recorder extends OneShotBehaviour{


		@Override
		public void action() {
			System.out.println("Agente agenteRecorder");
			recordSound();
			
			Utils.enviarMensaje(this.myAgent, "Reconoce", "sound.wav");
			System.out.println("Mensaje Enviado a Reconoce"); 

		}
	}

	public void recordSound() {
		final JavaSoundRecorder recorder = new JavaSoundRecorder();
		final long RECORD_TIME = 16000;
		// creates a new thread that waits for a specified
		// of time before stopping
		Thread stopper = new Thread(new Runnable() {
			public void run() {
				try {
					Thread.sleep(RECORD_TIME);
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				recorder.finish();
			}
		});

		stopper.start();

		// start recording
		recorder.start();
	}
}



